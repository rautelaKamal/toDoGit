### FullStack Development Course Assignments
Each assignment has its respective instructions for the setup, running, testing and submitting it.

- If you have any query then ping us on the Discord server.